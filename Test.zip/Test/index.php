<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
		<script type="text/javascript" src="jquery/jquery-3.3.1.min.js"></script>
	</head>
	<body>
		<div class="container">
			<h2 class="page-header">Choose Product</h2>
			<div class="row">
				<div class="col-sm-4">
					<img class="img-thumbnail" src="img/apple.jpg">
					<h3>Apple - <small>(AT5)</small></h3>
						<div class="input-group">
					      <select class="form-control">
					      	<option value="3" data-packs="3,0">3</option>
					      	<option value="5" data-packs="5,0">5</option>
					      	<option value="6" data-packs="3,3">6</option>
					      	<option value="8" data-packs="3,5">8</option>
					      	<option value="10" data-packs="5,5">10</option>
					      	<option value="13" data-packs="3,5,5">13</option>
					      	<option value="15" data-packs="5,5,5">15</option>
					      </select>
					      <span class="input-group-btn">
					        <button class="btn btn-success" data-code="AT5" type="button">Add to Cart</button>
					      </span>
					    </div><!-- /input-group -->
				</div>
				<div class="col-sm-4">
					<img class="img-thumbnail" src="img/bb.jpg">
					<h3>Blueberry Muffin - <small>(MB11)</small></h3>
						<div class="input-group">
						<select class="form-control">
					      	<option value="2" data-packs="2,0">2</option>
					      	<option value="4" data-packs="2,2">4</option>
					      	<option value="5" data-packs="5,0">5</option>
					      	<option value="7" data-packs="5,2">7</option>
					      	<option value="8" data-packs="8,0">8</option>
					      	<option value="10" data-packs="5,5">10</option>
					      	<option value="12" data-packs="8,2,2">12</option>
					      	<option value="13" data-packs="8,5">13</option>
					      	<option value="15" data-packs="5,5,5">15</option>
					      	<option value="16" data-packs="8,8">16</option>
					    </select>				
					    	<span class="input-group-btn">
					        <button class="btn btn-success" data-code="MB11" type="button">Add to Cart</button>
					      </span>
					    </div><!-- /input-group -->
				</div>
				<div class="col-sm-4">
					<img class="img-thumbnail" src="img/croissant.jpg">
					<h3>Croissant - <small>(CF)</small></h3>
						<div class="input-group">
					      <select class="form-control">
					      	<option value="3" data-packs="3,0">3</option>
					      	<option value="5" data-packs="5,0">5</option>
					      	<option value="8" data-packs="5,3">8</option>
					      	<option value="9" data-packs="9,0">9</option>
					      	<option value="10" data-packs="5,5">10</option>
					      	<option value="12" data-packs="9,3">12</option>
					      	<option value="13" data-packs="5,5,3">13</option>
					      	<option value="14" data-packs="9,5">14</option>
					      	<option value="18" data-packs="9,9">18</option>
					    </select>		
					      <span class="input-group-btn">
					        <button class="btn btn-success" data-code="CF" type="button">Add to Cart</button>
					      </span>
					    </div><!-- /input-group -->
				</div>
			</div>
			<table class="table table-bordered" style="margin-top:60px; margin-bottom:60px;" id="">
					<tr>
						<th class='text-center'> Product ID</th>
						<th class='text-center'> Quantity </th>
						<th class='text-center'> Packs </th>
						<th class='text-center'> Price </th>
					</tr>
					<tbody id="responce">


                    </tbody> 
			</table>
		</div>
		<script>
		jQuery(document).ready(function($){
			$(".btn").click(function(){
				var main_wrap = $(this).closest('.col-sm-4');
				var quantity = main_wrap.find('select').val();
				var data_arr = main_wrap.find(':selected').data('packs');
				var title = main_wrap.find('h3').text();
				var id = $(this).data('code');
				
	        	var html = '';
	        	html += '<tr>';
	        	html += '<td>'+id+'</td>';
	        	html += '<td>'+quantity+'</td>';
	        	html += '<td>'+data_arr+'</td>';
	        	html += '<td>'+get_price_markup(id, data_arr)+'</td>';
	        	html += '</tr>';
        		$("#responce").append(html);


			});

			function get_price_markup(id, data_arr){
				var html = '';
				console.log(data_arr);
				if (data_arr.search(',') == -1) {
					var array_of_data = [data_arr];
				} else {

					var array_of_data = data_arr.split(',');
				}
				var price = 0;
				for(var i = 0; i < array_of_data.length; i++){
					var g_pr = get_product_price(id, array_of_data[i]);

					html += '$'+g_pr+' + ';
					price += parseFloat(g_pr);
				}
				return html + ' = $'+price;
			}

			function get_product_price(id, qty){
				switch(id){
					case 'AT5':
						if(qty == '3'){
							return '6.99';
						}else if(qty == '0'){
							return '0';

						} else {
							return '8.99';
						}
					break;
					case 'MB11':
						if(qty == '2'){
							return '9.95';
						} else if(qty == '5'){
							return '16.95';

						}else if(qty == '0'){
							return '0';

						} else{
							return '24.95';
						}
					break;
					case 'CF':
						if(qty == '3'){
							return '5.95';
						} else if(qty == '5'){
							return '9.95';

						}else if(qty == '0'){
							return '0';

						} else{
							return '16.99';
						}
					break;
				}
			}
		});
		</script>
	</body>

</html>	